\*DEBRUP SARKAR,ROLL NO.=54,CSE
  ASSIGNMENT 5
  QUESTION 1> WRITE A MENU DRIVEN PROGRAM IN C WHICH WILL PERFORM THE FOLLOWING OPERATIONS ON LINKED LIST
              I)ADD A NODE AT THE END OF THE LIST(FOR EMPTY LIST IT WILL BE FIRST NODE OF THE LIST.
              II) NO. OF NODES PRESENT IN THE LIST.
              III) ADD A NEW NODE AT THE BEGINNING OF THE LIST.
              IV) ADD A NEW NODE AFTER THE SPECIFIED NO. OF NODES(E.G. ADD NODE AFTER SAY 5TH NODE)
              V) DISPLAY THE CONTENTS OF THE LIST.
*/

#include <stdio.h> 
#include <stdlib.h> 

struct Node 
{ 
int data; 
struct Node *next; 
}; 

void push(struct Node** head_ref, int new_data) 
{ 

struct Node* new_node = (struct Node*) malloc(sizeof(struct Node)); 

	new_node->data = new_data; 

	new_node->next = (*head_ref); 
	(*head_ref) = new_node; 
} 
void insertAfter(struct Node* prev_node, int new_data) 
{ 
	if (prev_node == NULL) 
	{ 
	printf("the given previous node cannot be NULL"); 
	return; 
	} 

	struct Node* new_node =(struct Node*) malloc(sizeof(struct Node)); 

	new_node->data = new_data; 

	new_node->next = prev_node->next; 

	prev_node->next = new_node; 
} 

void append(struct Node** head_ref, int new_data) 
{
	struct Node* new_node = (struct Node*) malloc(sizeof(struct Node)); 

	struct Node *last = *head_ref;
	new_node->data = new_data; 

	new_node->next = NULL; 

	if (*head_ref == NULL) 
	{ 
	*head_ref = new_node; 
	return; 
	} 
	while (last->next != NULL) 
		last = last->next; 

	last->next = new_node; 
	return; 
} 

int getCount(struct Node* head) 
{ 
    if (head == NULL) 
        return 0; 
 
    return 1 + getCount(head->next); 
} 
void printList(struct Node *node) 
{ 
while (node != NULL) 
{ 
	printf(" %d ", node->data); 
	node = node->next; 
} 
} 

int main() 
{ 
struct Node* head = NULL; 

int ch,p,q,r;
int c;
do
  {
      printf("MENU:");
      printf("\n1 for adding node at the end\n2 for counting no. of nodes\n3 for adding node at the beginning\n4 for adding a node after a specified no. of nodes\n5 for displaying the contents of the list");
      printf("\nEnter choice=");
      scanf("%d",&c);
      switch(c)
            {
             case 1:
                      printf("Enter data=");
                      scanf("%d",&p);
                      append(&head, p); 
                      break;
             case 2:
                      getCount(head);
                      break;
             case 3:
                      printf("Enter data=");
                      scanf("%d",&q);
                      push(&head, q); 
                      break;
             case 4:
                      printf("Enter data=");
                      scanf("%d",&r);
                      insertAfter(head->next, r);
                      break;
             case 5:
                      printf("\n Created Linked list is: "); 
                      printList(head); 
                      break;
             default:
                      printf("Invalid choice");
                      break;
            }
    printf("Want to continue?(Y=1/N=2)");
    scanf("%d",&ch);
  }while(ch==1);

return 0; 
} 

