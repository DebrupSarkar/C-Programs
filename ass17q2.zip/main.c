/*NAME=DEBRUP SARKAR,ROLL NUMBER=54,CSE
  ASSIGNMENT 17
  Q1>WRITE A MENU DRIVEN PROGRAM IN C TO IMPLEMENT A CIRCULAR QUEUE USING lINKED lIST.THE OPERATIONS ARE AS ENQUEUE,DEQUEUE AND DISPLAY*/
#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node* next;
};
struct node *f = NULL;
struct node *r = NULL;
void ENQUEUE(int d) 
    {
	 struct node* n;
	 n = (struct node*)malloc(sizeof(struct node));
	 n->data = d;
	 n->next = NULL;
	 if((r==NULL)&&(f==NULL))
	   {
		f = r = n;
		r->next = f;
	   } 
	 else
	   {
		r->next = n;
		r = n;
		n->next = f;
	   }
     } 
void DEQUEUE() 
   {
	struct node* t;
	t = f;
	if((f==NULL)&&(r==NULL))
		printf("\nQueue is Empty");
	else if(f == r){
		f = r = NULL;
		free(t);
	}
	else
	  {
		f = f->next;
		r->next = f;
		free(t);
	  }
	}
void DISPLAY()
    { 
	 struct node* t;
	 t = f;
	 if((f==NULL)&&(r==NULL))
	   	 printf("\nQueue is Empty");
	 else
	    {
		  do{
		   	 printf("\n%d",t->data);
			 t = t->next;
		    }while(t != f);
	     }
     }
int main()
{
	int opt,n,i,data;
	printf("MENU:\n1 for Insert the Data in Queue\n2 for show the Data in Queue \n3 for Delete the data from the Queue\n4 for Exit");
	do 
	  {
	     printf("\nEnter Your Choice:-");    
	     scanf("%d",&opt);
		 switch(opt)
		      {
		  	   case 1:
				     printf("\nEnter the number of data:");
				     scanf("%d",&n);
				     printf("\nEnter your data:");
				     i=0;
				     while(i<n)
				     {
					   scanf("%d",&data);
					   ENQUEUE(data);
					   i++;
				      }
				     break;
			   case 2:
				     DISPLAY();
				     break;
			   case 3:
			    	 DEQUEUE();
				     break;
			   case 4:
				     break;
			   default:
			     	  printf("\nIncorrect Choice");
	                  break; 
		       }   
	}while(opt!=4);
return 0;
}